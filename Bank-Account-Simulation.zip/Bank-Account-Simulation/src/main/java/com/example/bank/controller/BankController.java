package com.example.bank.controller;

import com.example.bank.model.Account;
import com.example.bank.service.BankService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bank")
public class BankController {
    private final BankService bankService;

    public BankController(BankService bankService) {
        this.bankService = bankService;
    }

    @GetMapping("/account")
    public Account getAccount() {
        return bankService.getAccount();
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam double amount) {
        return bankService.deposit(amount) != null ? "OK" : "ERROR";
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam double amount) {
        return bankService.withdraw(amount) != null ? "OK" : "INSUFFICIENT";
    }

}
