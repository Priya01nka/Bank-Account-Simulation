package com.example.bank.service;

import com.example.bank.model.Account;
import com.example.bank.model.Transaction;
import com.example.bank.repository.AccountRepository;
import com.example.bank.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.time.LocalDateTime;

@Service
public class BankService {

    private final AccountRepository accountRepo;
    private final TransactionRepository transactionRepo;

    public BankService(AccountRepository accountRepo, TransactionRepository transactionRepo) {
        this.accountRepo = accountRepo;
        this.transactionRepo = transactionRepo;
    }

    @PostConstruct
    public void init() {
        // Create a default account
        if (accountRepo.findByAccountNumber("123456") == null) {
            accountRepo.save(new Account("123456", 0));
        }
    }

    public Account getAccount() {
        return accountRepo.findByAccountNumber("123456");
    }

    public Account deposit(double amount) {
        Account account = getAccount();
        account.setBalance(account.getBalance() + amount);

        Transaction tx = new Transaction("Deposit", amount, LocalDateTime.now(), account);
        account.getTransactions().add(tx);

        transactionRepo.save(tx);
        accountRepo.save(account);

        return account; // return updated account
    }

    public Account withdraw(double amount) {
        Account account = getAccount();
        if (account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);

            Transaction tx = new Transaction("Withdraw", amount, LocalDateTime.now(), account);
            account.getTransactions().add(tx);

            transactionRepo.save(tx);
            accountRepo.save(account);

            return account; // success
        }
        return null; // insufficient funds
    }
}

