const API = "/api/bank"; // No localhost needed since same server

async function loadAccount() {
  const res = await fetch(`${API}/account`);
  const acc = await res.json();
  document.getElementById("balance").innerText = acc.balance.toFixed(2);
  const ul = document.getElementById("transactions");
  ul.innerHTML = "";
  acc.transactions.slice().reverse().forEach(t => {
    const li = document.createElement("li");
    li.textContent = `${t.date} — ${t.type}: ${t.amount}`;
    ul.appendChild(li);
  });
}

async function deposit() {
  const amount = parseFloat(document.getElementById("amount").value);
  if (!amount || amount <= 0) return setStatus("Enter a positive amount");
  await fetch(`${API}/deposit?amount=${amount}`, { method: "POST" });
  setStatus(`Deposited ${amount}`);
  loadAccount();
}

async function withdraw() {
  const amount = parseFloat(document.getElementById("amount").value);
  if (!amount || amount <= 0) return setStatus("Enter a positive amount");
  const res = await fetch(`${API}/withdraw?amount=${amount}`, { method: "POST" });
  const txt = await res.text();
  if (txt === "INSUFFICIENT") setStatus("Insufficient balance");
  else setStatus(`Withdrew ${amount}`);
  loadAccount();
}

function setStatus(msg) {
  document.getElementById("status").innerText = msg;
}

document.getElementById("btnDeposit").addEventListener("click", deposit);
document.getElementById("btnWithdraw").addEventListener("click", withdraw);

loadAccount();
